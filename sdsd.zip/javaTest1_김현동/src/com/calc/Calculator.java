package com.calc;

public class Calculator {

	public static void main (String []args) {
	
	int a = 	Integer.parseInt(args[0]); //4 
	int b =     Integer.parseInt(args[1]); // 2
	
	 int sum = a+b;
	 int minus = a-b;
	 int multi = a*b;
	 int division = a/b;
	 if (a <=0) division = 0;
	 
	System.out.println("합 : "+sum);	
	System.out.println("차 : "+minus);	
	System.out.println("곱 : "+multi);	
	
	System.out.println("나누기 : "+division);	
		
}
	
}
