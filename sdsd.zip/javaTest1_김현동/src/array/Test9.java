package array;

public class Test9 {
	
	public static void main (String [] args) {
		
		int[][]array = {{12,41,36,56},  // 4행 4열
					{82,10,12,61},
					{14,16,18,78},
					{45,26,72,23}};
		
		int max  = array[0][0];
		int min  = array[3][3];
		
		
		for (int i = 0 ; i < array.length-1;i++) {
			
			for (int j = 0 ; j<array[0].length;j++) {
					//82  >  10
				if ( min> array[i][j] ) {
					 min  = array[i][j];
				}
				if (max <array[i][j]) {
					max =array [i][j];
				}
			}
		}
		
		System.out.println("가장 큰값 "+max);
		System.out.println("가장 작은 값 "+min);
		
		}
		
}
	

