package test.controller;

import java.util.Scanner;

public class Test1 {

	public static void main (String [] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("정수를 입력하세요.");
		
		int num = sc.nextInt();
		String str ="";
		
		int a = 2;
		if ( num %2 ==  0   ) {
		 str = "배수 입니다.";
			}else {
				str= "배수가 아닙니다.";
			}
	
		System.out.printf("2의"+str);
	}
}
