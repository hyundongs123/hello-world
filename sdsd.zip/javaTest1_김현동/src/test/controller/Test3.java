package test.controller;

public class Test3 {

	public static void main (String []args) {
		
		int i = 1;
		double sum = 0;
		double avg = 0;
		while (i <=100) {
			
			sum+=i ;
			i++;
		}
		avg = sum /100 ;
	
	System.out.printf("합계  : %.0f\n",sum);
	System.out.println("평균  : "+avg);
	
	}
	
}
