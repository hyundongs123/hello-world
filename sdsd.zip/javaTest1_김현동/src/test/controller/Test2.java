package test.controller;

public class Test2 {

	public static void main (String[] args) {
		
		for (int i = 2; i <=5 ; i++) {
			for (int j = 0; j <10 ; j++) {
				int multi =  i *j ;

				if (multi%2 == 1) {
					System.out.println(i+"*"+j+"="+i*j);
				}
			}
		
	}
	
	
	
	}
	}
