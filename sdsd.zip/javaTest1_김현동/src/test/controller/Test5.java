package test.controller;

import java.util.Scanner;


public class Test5 {

	public static void main(String [] args) {
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println("두개의 정수를 입력하세요 (1~9) 까지");
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		String s = "";
		
		
		if((n1 >=1 && n1<10) &&(n2>=1 &&n2<10)) {
			if(n1*n2 <10) {
				s = "한자리 수";
			}else {
				s= "두자리수 ";
			}
			System.out.printf("%s 입니다.",s);
			
		}else {
			System.out.println("잘못입력하셨습니다.");
		}

		
	}
}